a=input("Enter Number: ")
x=int(a)
if x%4==0:
    print("Number is a multiplication of 4.")
elif x%2==0:
    print("Number is even.")
elif x==0:
    print("Number is 0.")
else:
    print("Number is odd.")
