x=input("Write a number - ")
y=input("Write another number - ")

variable=int(x)
divider=int(y)

if(variable%divider==0):
    print("First number can be divided by second number.")
else:
    print("First number doesn't divide by second number.")
