x=0
i=1000
while (i>5):
    a=i%3
    b=i%5
    if (b==0) or (a==0):
        x+=i
    i-=1
print(x)