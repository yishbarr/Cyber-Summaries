
public class Petek {

	private char letParty;
	private String partyName;
	
	//constructor
	public Petek(char a, String partyName) {
		this.letParty = a;
		this.partyName = partyName;
	}
	//Get letter
	public char getLetParty() {
		return letParty;
	}
	//Get Party Name
	public String getPartyName() {
		return partyName;
	}
	// Set Letter
	public void setLetParty(char LP) {
		if(LP=='A'|LP=='Y'|LP=='B'|LP=='L')
		letParty=LP;
		else
		System.out.println("Party doesn't exist.");
	}
	//Set Party Name
	public void setPartyName(String PN) {
		partyName=PN;
	}
}
