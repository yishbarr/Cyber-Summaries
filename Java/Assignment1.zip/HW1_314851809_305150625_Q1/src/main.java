import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		
		
		//create BallotBox
		BallotBox Ariel =new BallotBox(1);
		
		
		
		//add Peteks
		Scanner scan= new Scanner(System.in);
		
		for(int i = 0;i<5;i++) {
			System.out.println("Enter a Petek - ");
			char x = scan.next().charAt(0);
			switch(x) {
			case 'A':
			case 'a': Ariel.addPetek(new Petek('A', "Aparty")); break;
			case 'L':
			case 'l': Ariel.addPetek(new Petek('L', "Lparty"));break;
			case 'Y':
			case 'y': Ariel.addPetek(new Petek('Y', "Yparty"));break;
			case 'B':
			case 'b': Ariel.addPetek(new Petek('B', "Bparty"));break;
			default: System.out.println("No Such Petek."); i--;
			}
			}
		
		
		//Results
		Ariel.getResults();
		
	}

}
