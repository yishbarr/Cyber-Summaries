
public class BallotBox {
	
	private int ballotNum;
	private Petek[] Ptk;
	private int index;
	
	int count=0;
	
	//constructor
	public BallotBox(int ballotNum) {
		this.ballotNum = ballotNum;
		Ptk = new Petek[100];
		index=0;
	}
	//Add Petek
	public void addPetek(Petek pK) {
		if (index<100) {
		Ptk[index]=pK;
		index++;
		}
	}
	//Get Petek
	public Petek getPetek(int i) {
		return Ptk[i];
	}
	public void getResults() {
		//count votes		
			int countA = 0, countB=0, countL=0, countY=0;
			for(int i = 0;i<index;i++){
				if(Ptk[i].getLetParty()=='A')
					countA++;
				if(Ptk[i].getLetParty()=='B')
					countB++;
				if(Ptk[i].getLetParty()=='L')
					countL++;
				if(Ptk[i].getLetParty()=='Y')
					countY++;
				}
				
				//print votes
				System.out.println("Number of votes:");
				System.out.println("A - "+countA);
				System.out.println("L - "+countL);
				System.out.println("Y - "+countY);
				System.out.println("B - "+countB);
	}
	
	
	

}
