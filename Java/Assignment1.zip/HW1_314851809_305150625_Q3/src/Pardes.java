
public class Pardes {
	private String name;
	private OrangeTree[] trees;
	
//construct object
public Pardes(String name) {
	this.name = name;
	this.trees =new OrangeTree[100];
}
//report the highest quantity of seasonal oranges
public int getMostOranges(OrangeTree[] trees) {
	int x;
	int y = 0;
	for(int i = 0;i<3;i++) {
		x=trees[i].getAllOranges();
		if(x>y)
			y=x;
	}
		return y;
	}
}



