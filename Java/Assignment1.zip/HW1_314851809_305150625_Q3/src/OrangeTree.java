public class OrangeTree
{
  private  int [] orange;
  
  public OrangeTree(){
	// number of oranges harvested in 90 days
	  orange = new int[90]; 
  }
  // set number of oranges harvested in a day
  public void setOrangeInDay(int o,int day){
	  orange[day-1]=o;
  }
  // get number of oranges harvested in a day, pass as parameter
  public int getOrangeInDayO(int day){
	  return orange[day-1];
  }
  //get all seasonal oranges.
  public int getAllOranges() {
	  int x = 0;
	for(int i = 0;i<90;i++)
		  x+=getOrangeInDayO(i);
	return x;
  }
}
