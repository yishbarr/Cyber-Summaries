import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		//make and set trees
		//set days and oranges for a
		OrangeTree a=new OrangeTree();
		a.setOrangeInDay(5, 5);
		

		//set days and oranges for b
		OrangeTree b=new OrangeTree();
		b.setOrangeInDay(8, 8);
		b.setOrangeInDay(78, 65);
		

		//set days and oranges for c
		OrangeTree c=new OrangeTree();
		c.setOrangeInDay(45, 3);
				
		
		//make tree array
		OrangeTree[] trees=new OrangeTree[3];
		trees[0]=a;
		trees[1]=b;
		trees[2]=c;
		
		//make object for function
		Pardes p= new Pardes("example");
		
		System.out.println(p.getMostOranges(trees));
		
	}
}
