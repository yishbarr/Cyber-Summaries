public class OrangeTree {
	private int[] numberPerDay;
	
public OrangeTree() {
	numberPerDay=new int[90];
	}
public void setDay(int day, int num) {
	if(day-1>=90||day-1<0)
		System.out.println("Day must be between 1 and 90!");
	else 
	numberPerDay[day-1]=num;
}
public int getOrangesPerDay(int day) {
	if(day-1>numberPerDay.length&&day-1<0) 
		return numberPerDay[day-1];
	else
		System.out.println("Day must be between 1 and 90!");
	return 0;
}
public int getAllOranges() {
	int x = 0;
	for(int i=0;i<numberPerDay.length;i++)
		x+=numberPerDay[i];
	return x;
	}

		
}

