import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		
		//make pardes
		Pardes pard = new Pardes();
		
		//make tree
		OrangeTree big =new OrangeTree();
				
		pard.addTree(big);
		
		
		
		//add oranges
		for(int i = 0;i<5;i++) {
		System.out.println("Write which day - ");
		int orangeday = scan.nextInt();
		System.out.println("Write how many oranges for day "+orangeday+" - ");
		int orangenum = scan.nextInt();
		
		big.setDay(orangeday, orangenum);
		}
		
		
		
		
		boolean flag=pard.count400(pard.getTree(0));
		System.out.println("Does tree have over 400? "+flag);
		}

	
	
}
