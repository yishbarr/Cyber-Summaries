
public class Pardes {
private OrangeTree[] trees;
int index=0;

public Pardes() {
	this.trees=new OrangeTree[100];
}
public void addTree(OrangeTree newTree) {
	if(index<trees.length) {		
	trees[index]=newTree;
	index++;
	}
	else
		System.out.println("Can't add more trees.");
}
public boolean count400(OrangeTree ot) {
	return ot.getAllOranges()>=400;

}
public OrangeTree getTree(int index) {
	return trees[index];
	
}
}
